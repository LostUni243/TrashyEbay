﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ManagementPortal.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PayRate = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Hours = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "Hours", "Name", "PayRate", "StartDate", "Title" },
                values: new object[] { 1, 40m, "Luke Skywalker", 30m, new DateTime(2010, 6, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Human Resources Manager" });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "Hours", "Name", "PayRate", "StartDate", "Title" },
                values: new object[] { 2, 40m, "Leia Organa", 18m, new DateTime(2007, 12, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "Junior Accountant" });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "Hours", "Name", "PayRate", "StartDate", "Title" },
                values: new object[] { 3, 35m, "Erza Bridger", 22m, new DateTime(2018, 9, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Sales Associate" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employees");
        }
    }
}
