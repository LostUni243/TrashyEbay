﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ManagementPortal.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace ManagementPortal.Data
{
    public class EmployeeContext : IdentityDbContext<User>
    {
        public EmployeeContext (DbContextOptions<EmployeeContext> options) : base(options)
        { }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Product> Products { get; set; } //CREATES THE ENTITY

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Employee>()
                .Property(p => p.PayRate)
                .HasColumnType("decimal(18,2)");    //#Potential: Somehow adapt to products.price for decimals to work for updating the database?
            modelBuilder.Entity<Employee>()
                .Property(p => p.Hours)
                .HasColumnType("decimal(18,2)");
            modelBuilder.Entity<Department>().HasData(
                new Department { DepartmentID = "AD", DepartmentName = "Administration"},
                new Department { DepartmentID = "AC", DepartmentName = "Accounting"},
                new Department { DepartmentID = "IT", DepartmentName = "Information Technology"},
                new Department { DepartmentID = "CS", DepartmentName = "Customer Service" },
                new Department { DepartmentID = "SA", DepartmentName = "Sales" },
                new Department { DepartmentID = "OP", DepartmentName = "Operations" }
                );
            modelBuilder.Entity<Employee>().HasData(
                new Employee
                {
                    Id = 1,
                    Name = "Luke Skywalker",
                    StartDate = new DateTime(2010, 6, 15),
                    Title = "Human Resources Manager",
                    PayRate = 30,
                    Hours = 40,
                    DepartmentID="AD"
                },
                new Employee
                {
                    Id = 2,
                    Name = "Leia Organa",
                    StartDate = new DateTime(2007, 12, 17),
                    Title = "Junior Accountant",
                    PayRate = 18,
                    Hours = 40,
                    DepartmentID = "AC"
                },
                new Employee
                {
                    Id = 3,
                    Name = "Erza Bridger",
                    StartDate = new DateTime(2018, 9, 20),
                    Title = "Sales Associate",
                    PayRate = 22,
                    Hours = 35,
                    DepartmentID = "SA"
                }
            );

            /*
            Error in updating database?:
              No type was specified for the decimal property 'Price' on entity type 'Product'. This will cause values to be silently truncated if they do not fit in the default precision and scale. Explicitly 
              specify the SQL server column type that can accommodate all the values in 'OnModelCreating' using 'HasColumnType()', specify precision and scale using 'HasPrecision()' or 
              configure a value converter using 'HasConversion()'.
            To the internet for potential fixes! Will use "#Potential" to indicate suggestions found
            */

            //THE STARTING PRODUCT LIST
            modelBuilder.Entity<Product>()  //this fix did the trick it seems
                .Property(p => p.Price)
                .HasColumnType("decimal(10,2)");
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    Id = 1,
                    Name = "LightSaber",
                    Description = "Laser sword useful for cutting objects.",
                    Inventory = 42,
                    Price = 29.99M
                },
                new Product
                {
                    Id = 2,
                    Name = "Bones",
                    Description = "From fake bones to real bones on purchase you can choose which to have otherwise expect a random mix of the two types.",
                    Inventory = 666,
                    Price = 342.00M
                },
                new Product
                {
                    Id = 3,
                    Name = "Scale",
                    Description = "A simple scale for weighing objects up to 1k pounds. The scale is a floor type where you can place the thing to be measured on top of the scale.",
                    Inventory = 3460,
                    Price = 200.00M
                },
                new Product
                {
                    Id = 4,
                    Name = "Random Monster Movie",
                    Description = "As the name suggests the product is a random movie involving some kind of monster. Examples are Godzilla, Aliens, Predators, Pacifc Rim, and etc.",
                    Inventory = 92383,
                    Price = 60.99M
                },
                new Product
                {
                    Id = 5,
                    Name = "Random Comic Book",
                    Description = "As the name suggests the product is a random comic book. Examples are Spider-Man, V for Vendetta, X-Factor, GTO: Great Teacher Onizuka, and etc.",
                    Inventory = 625627,
                    Price = 25.99M
                }
            );
        }
    }
}
